import Vue from 'vue'
import Router from 'vue-router'

// User
import User from '../views/user/list'
import AddUser from '../views/user/add'
import EditUser from '../views/user/edit'
import DetailUser from '../views/user/detail'

// Product
import Product from '../views/product/list'

// Voucher
import Voucher from '../views/voucher/list'

// Banner
import Banner from '../views/banner/list'

// Plannogram
import Plannogram from '../views/plannogram/list'

// Article
import Article from '../views/article/list'

// Notification
import Notification from '../views/notification/list'

// DeliveryMethod
import DeliveryMethod from '../views/delivery-method/list'

Vue.use(Router)

export default new Router({
	routes: [
		{
			path: '/',
			name: 'list-user',
			component: User
		},
		{
			path: '/list-user',
			name: 'list-user',
			component: User
		},
		{
			path: '/add-user',
			name: 'add-user',
			component: AddUser
		},
		{
			path: '/edit-user/:id',
			name: 'edit-user',
			component: EditUser
		},
		{
			path: '/detail-user/:id',
			name: 'detail-user',
			component: DetailUser
		},
		{
			path: '/list-product',
			name: 'list-product',
			component: Product
		},
		{
			path: '/list-voucher',
			name: 'list-voucher',
			component: Voucher
		},
		{
			path: '/list-banner',
			name: 'list-banner',
			component: Banner
		},
		{
			path: '/list-plannogram',
			name: 'list-plannogram',
			component: Plannogram
		},
		{
			path: '/list-article',
			name: 'list-article',
			component: Article
		},
		{
			path: '/list-notification',
			name: 'list-notification',
			component: Notification
		},
		{
			path: '/list-delivery-method',
			name: 'list-delivery-method',
			component: DeliveryMethod
		}
	]
})
