<template>
    <div>
        <Menu/>
    </div>
</template>

<script>
import Menu from "../../components/menu.vue"
export default {
	name: 'list-plannogram',
	components: {
		Menu
	}
}
</script>