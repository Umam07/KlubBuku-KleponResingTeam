<template>
    <div>
        <Menu/>
    </div>
</template>

<script>
import Menu from "../../components/menu.vue"
export default {
	name: 'list-delivery-method',
	components: {
		Menu
	}
}
</script>