package model

// tags
type User struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type Datauser struct {
	ID       uint   `gorm:"primaryKey;autoIncrement" json:"id"`
	Name     string `json:"name"`
	Username string `json:"username"`
	Email    string `json:"email"`
	Role     string `json:"role"`
	Image    string `json:"image"`
}
