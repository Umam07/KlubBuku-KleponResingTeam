package main

import (
	"dpw-latihan/database"
	"dpw-latihan/model"
	"encoding/json"
	"io"
	"net/http"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
)

func main() {

	r := chi.NewRouter()
	db := database.InitDB()

	// Middleware to set CORS headers
	r.Use(middleware.SetHeader("Content-Type", "application/json"))
	r.Use(corsMiddleware)

	// Old List User
	r.Get("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		var data []model.User
		var response []byte
		_ = db.Table("users").Find(&data)

		response, _ = json.Marshal(data)

		w.Write(response)
	})

	// Old Create User
	r.Post("/", func(writer http.ResponseWriter, request *http.Request) {
		writer.Header().Set("Content-Type", "application/json")
		var payload model.User
		var data []byte
		var err error

		data, err = io.ReadAll(request.Body)
		if err != nil {
			writer.Write([]byte("terjadi error diaplikasi kita"))
			return
		}
		err = json.Unmarshal(data, &payload)
		if err != nil {
			writer.Write([]byte("terjadi error diaplikasi kita"))
			return
		}
		_ = db.Create(&payload)
		data, err = json.Marshal(payload)

		writer.Write(data)
	})

	//Get List User
	r.Get("/user", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		var data []model.Datauser
		var response []byte
		_ = db.Table("datausers").Find(&data)

		response, _ = json.Marshal(data)

		w.Write(response)
	})

	//Create User
	r.Post("/user", func(writer http.ResponseWriter, request *http.Request) {
		writer.Header().Set("Content-Type", "application/json")
		var payload model.Datauser
		var data []byte
		var err error

		data, err = io.ReadAll(request.Body)
		if err != nil {
			writer.Write([]byte("terjadi error diaplikasi kita"))
			return
		}
		err = json.Unmarshal(data, &payload)
		if err != nil {
			writer.Write([]byte("terjadi error diaplikasi kita"))
			return
		}
		_ = db.Create(&payload)
		data, err = json.Marshal(payload)

		writer.Write(data)
	})

	http.ListenAndServe(":3001", r)

}

// CORS middleware
func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusOK)
			return
		}

		next.ServeHTTP(w, r)
	})
}
